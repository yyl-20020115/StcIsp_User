/*
ע��:
  #ifdef STCISP_USED_CODE
	    ... 
	#endif 
	֮��Ĵ�����Ҫ���ϲ���Ŀ�������
  ��������Ҫ����iap_sys_init	
*/

#define STCISP_USED_CODE
#ifdef  STCISP_USED_CODE
#include "stc15.h"
#include "intrins.h"

#define DEFAULT_LEADING_SYMBOL 0x7f
#define DEFAULT_LEADING_SIZE   0x40
#define IAP_RESET_CMD 0x20

#ifdef USE_HIGH_FREQUENCY
#define FOSC                    24000000UL
#else
#define FOSC                    11059200UL
#endif
#define BAUD                    (65536 - FOSC/4/115200)

#define DFU_TAG				 0x12abcd34			 //DFUǿ��ִ�б�־
long xdata DfuFlag _at_ 0x0efc;				 //DFU��־, ������xdata�����4�ֽ�

void iap_sys_init()
{
		P0M0 = 0x00;
		P0M1 = 0x00;
		P1M0 = 0x00;
		P1M1 = 0x00;
		P2M0 = 0x00;
		P2M1 = 0x00;
		P3M0 = 0x00;
		P3M1 = 0x00;
		P4M0 = 0x00;
		P4M1 = 0x00;
		P5M0 = 0x00;
		P5M1 = 0x00;
		P6M0 = 0x00;
		P6M1 = 0x00;
		P7M0 = 0x00;
		P7M1 = 0x00;
		
		DfuFlag = 0;

    AUXR &= ~0x01;
    SCON = 0x52;
    
    AUXR |= 0x40;
	
    TMOD &= ~0xf0;
  
    TL1 = BAUD;
    TH1 = BAUD >> 8;
    TR1 = 1;
	  ES=1;
		EA = 1;

}


unsigned char got = 0;
int symbols_count = 0;

void iap_uart_int() interrupt 4
{
	if(TI)
	{
		TI = 0;
	}
	if(RI)
	{
		RI = 0;
		got = SBUF;
		if(got == DEFAULT_LEADING_SYMBOL)
		{
			if (++symbols_count>=DEFAULT_LEADING_SIZE)
			{
					symbols_count = 0;
					DfuFlag = DFU_TAG;
					IAP_CONTR = IAP_RESET_CMD;
			}

		}else{
			symbols_count = 0;
		}
	}
}
#endif

int main()
{

#ifdef  STCISP_USED_CODE
		iap_sys_init();
#endif
		P0 = 0x55;
	  while (1)
		{
			P0 = ~P0;
		}
}



